Changelog
=========

[2012-Apr-12]

1. Removed the need for requiring the sdk.class.php library in the autoload.php file by moving the require to the service.xml definition
2. Step 4 of the documentation removed to reflect the change above
3. Added a Changelog document
4. Other minor documentation tweaks

