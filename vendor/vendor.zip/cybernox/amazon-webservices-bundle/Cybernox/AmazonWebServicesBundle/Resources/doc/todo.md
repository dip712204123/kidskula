# Amazon Web Services Bundle - TODO#

1. Refactor aws-sdk-for-php (or find what we can pass in during instantiation to circumvent) so the config.inc.php file presence issue isn't an issue

2. Integrate the cloudfusion AmazonPAS functionality

3. Condense/Consolidate the Factory and service instantiation

